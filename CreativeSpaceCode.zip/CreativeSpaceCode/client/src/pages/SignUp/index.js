// SignUp/Index.js

export { default } from "./SignUp.js";
