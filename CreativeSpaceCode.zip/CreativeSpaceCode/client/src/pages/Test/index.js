// SignUp/Index.js

export { default } from "./Test.js";
