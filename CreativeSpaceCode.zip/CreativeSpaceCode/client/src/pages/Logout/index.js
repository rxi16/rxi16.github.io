// src/pages/Logout/index.js
export { default } from "./Logout.js";
