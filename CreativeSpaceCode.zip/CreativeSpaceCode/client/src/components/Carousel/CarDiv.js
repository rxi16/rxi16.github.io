import React from "react";

export const CarDiv = ({ children }) =>
	<div 
		className="carousel-inner" 
		role="listbox">{children}
    </div>;