// Footer/index.jss
export { default } from "./Footer";
