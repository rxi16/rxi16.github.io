import React from "react";

export const Input = props =>
	<input 
		type="text"
		className="form-control" 
		{...props} />;
