import React from "react";

export const FormDiv = ({ children }) =>
	<div className="form-group">
		{children}
	</div>;