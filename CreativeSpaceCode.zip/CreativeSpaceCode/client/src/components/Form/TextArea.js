import React from "react";

export const TextArea = props =>
    <textarea 
    	className="form-control" {...props} />;
