import React from "react";

export const DisplayMessage = props =>
	<div>
		<h1 
	      	type="text"
	      	{...props}>
	    </h1>
	</div>;