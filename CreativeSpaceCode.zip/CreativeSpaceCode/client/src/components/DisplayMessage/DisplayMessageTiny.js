import React from "react";

export const DisplayMessageTiny = props =>
	<div>
		<p 
	      	type="text"
	      	{...props}>
	    </p>
	</div>;