import React from "react";

export const ArchImg = props =>
	<img
		className="img-fluid"
		alt="Creation"
		{...props} />;  