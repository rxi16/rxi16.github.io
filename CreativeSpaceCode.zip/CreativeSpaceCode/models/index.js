// models/index.js
module.exports = {
  Artist: require("./artist"),
  Creation: require("./creation"),
  Session: require("./session")
};
